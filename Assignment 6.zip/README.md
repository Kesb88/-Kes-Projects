# WEB322 Project (Fall 2023)I declare that this assignment is my own work in accordance with the Seneca Academic Policy.
No part of this assignment has been copied manually or electronically from any other source(including web sites) or distributed to other students.
Student Name : Kester Bascillo
Student Email : kbascillo@myseneca.ca
Course/Section: WEB322/NEE
## Project URLs
GitHub Repo : https://github.com/Kesb88/web322-kbascillo
Cyclic URL : https://tan-repulsive-pigeon.cyclic.app
